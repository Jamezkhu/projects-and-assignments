# NEXT.JS PROJECT

## JAMES KHURWAL

## GITHUB REPO ADDRESS

My repo is located at:

https://github.com/Jamezkhu/projects-and-assignments.git

Under the folder cantor-assignment-semester1

## CONFIRMATION OF FILES

I confirm I have zipped the files in the format of:
├── database
├── evidence
│   ├── lighthouse-audits
│   ├── wireframes
├── website_code
│   ├── /src
│   ├── package.json
│   ├── .gitignore

I confirm I have only included files needed to run the application.